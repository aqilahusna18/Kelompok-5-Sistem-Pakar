# Sistem Pakar Diagnosa Estetika Kulit Wanita (Certainty Factor)

Aplikasi web Sistem Pakar untuk mendiagnosa jenis masalah estetika kulit pada wanita berdasarkan gejala klinis menggunakan metode **Certainty Factor (CF)** multi-premis.

Proyek ini dibangun untuk memenuhi tugas mata kuliah **Kecerdasan Buatan (Artificial Intelligence)**, Fakultas Sains dan Teknologi, **Universitas Harkat Negeri**.

> **Referensi Ilmiah Utama:**  
> Jurnal JIdT (Jurnal Informasi dan Teknologi) Vol. 2 No. 4 (2020)  
> Penulis: Subrianto Chandra, Yuhandri Yunus, & Sumijan.

---

## 🌟 Fitur Baru: Arsitektur Multi-Slide & Riwayat Konsultasi

Aplikasi ini telah dirancang ulang menjadi **sistem slide mandiri (multi-tab view)** yang rapi dan terisolasi:

1. **Slide 1 - Panduan & Informasi (`slide-panduan`)**:
   - Beranda, pengenalan sistem pakar dermatologi, petunjuk 3 langkah konsultasi, kredensial akademik, dan penjelasan rumus matematika.
2. **Slide 2 - Form Konsultasi & Hasil Diagnosis (`slide-konsultasi`)**:
   - Input nama & usia pasien.
   - Pilihan demo cepat skenario pengujian (Keloid, Melasma, Akne, Selulit, Penuaan, Veruka, dan Kasus Seri/Draw).
   - Pencarian real-time untuk 29 gejala.
   - Kartu gejala interaktif dengan 5 skala kepastian CF User (0.0 s.d 1.0).
   - Hasil diagnosis utama, perbandingan 6 penyakit, transparansi langkah kombinasi berantai, serta tombol cetak laporan PDF.
3. **Slide 3 - Riwayat Konsultasi Pasien (`slide-riwayat`)**:
   - Menyimpan seluruh hasil rekam medis konsultasi pasien di `localStorage` peramban.
   - Dilengkapi badge counter jumlah konsultasi di navigasi.
   - Fitur lihat rincian rekam medis pasien di modal interaktif, cetak ulang, atau hapus riwayat.
4. **Slide 4 - Basis Pengetahuan (`slide-basis-pengetahuan`)**:
   - Halaman khusus eksplorasi basis pengetahuan pakar:
     - Tabel 6 Data Diagnosa Penyakit & Solusi Lengkap.
     - Tabel 29 Gejala Klinis dengan kolom pencarian.
     - Tabel 28 Aturan Inferensi (Rules) dengan kolom pencarian.
     - Tabel Skala Nilai CF User dan interpretasi klinisnya.

---

## 📁 Struktur File Proyek

Proyek ini menggunakan teknologi web murni (**Vanilla HTML5, CSS3, & JavaScript ES6+**) tanpa memerlukan build tool:

- [`index.html`](index.html) : Struktur navigasi multi-slide, formulir 29 gejala, modal riwayat, modal validasi, dan tabel transparansi.
- [`style.css`](style.css) : Desain responsif, animasi transisi antar-slide, kartu rekam medis riwayat, dan *print stylesheet* PDF.
- [`script.js`](script.js) : Mesin inferensi Certainty Factor, manajemen tab/slide, penyimpanan riwayat `localStorage`, serta filter pencarian.

---

## 🧮 Logika & Rumus Matematis Certainty Factor (CF)

1. **Perhitungan CF per-Rule (Premis Jamak AND):**
   $$\text{CF}_{user}(R) = \min(\text{CF}_{user}(G_1), \text{CF}_{user}(G_2), \dots, \text{CF}_{user}(G_n))$$
   $$\text{CF}(R) = \text{CF}_{user}(R) \times \text{CF}_{pakar}(R)$$

2. **Kombinasi Aturan Berantai (Sequential Combine):**
   $$\text{CF}_{gabung}(CF_1, CF_2) = CF_1 + CF_2 \times (1 - CF_1)$$
   $$\text{CF}_{baru} = \text{CF}_{lama} + CF_i \times (1 - \text{CF}_{lama})$$

3. **Persentase Keyakinan Akhir:**
   $$\text{Persentase} = \text{CF}_{akhir} \times 100\%$$

---

## 🚀 Panduan Menjalankan & Deploy

### Jalankan di Komputer Lokal:
- Cukup klik ganda (double-click) file `index.html` pada File Explorer untuk langsung membukanya di browser apa pun.
- Atau klik kanan $\to$ **Open with Live Server** di Visual Studio Code.

### Deploy Gratis ke Internet:
1. **GitHub Pages**: Unggah seluruh file ke repositori GitHub $\to$ aktifkan GitHub Pages dari branch `main`.
2. **Netlify Drop**: Buka [app.netlify.com/drop](https://app.netlify.com/drop) dan seret folder proyek.
3. **Vercel**: Hubungkan akun GitHub Anda di [vercel.com](https://vercel.com) dan klik Deploy.
