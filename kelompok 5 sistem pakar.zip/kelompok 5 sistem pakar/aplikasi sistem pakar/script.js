/**
 * ============================================================================
 * SISTEM PAKAR DIAGNOSA ESTETIKA KULIT WANITA (METODE CERTAINTY FACTOR)
 * ============================================================================
 * Tugas Mata Kuliah : Kecerdasan Buatan (Artificial Intelligence) / Fakultas Sains dan Teknologi, Universitas Harkat Negeri
 * Referensi Ilmiah  : Jurnal JIdT Vol. 2 No. 4 (2020) oleh Subrianto Chandra, Yuhandri Yunus, & Sumijan
 * Arsitektur Kode   : Multi-Slide Tab SPA, Vanilla JS (ES6+), Modular, LocalStorage History
 * ============================================================================
 */

"use strict";

/* ============================================================================
   1. BASIS PENGETAHUAN (KNOWLEDGE BASE)
   ============================================================================ */

/**
 * A. DATA DIAGNOSA PENYAKIT (P) - 6 Penyakit Estetika Kulit
 */
const DISEASES = {
  KEP01: {
    id: "KEP01",
    name: "Keloid",
    description: "Keloid adalah pertumbuhan jaringan parut berlebih yang meluas melampaui batas luka asli. Berwarna merah muda hingga keunguan, kenyal saat diraba, dan kerap terasa gatal atau nyeri.",
    solution: "Hindari memencet/menggaruk luka, hindari tindik atau tato di area berisiko. Konsultasikan ke dokter spesialis kulit untuk penanganan medis seperti injeksi kortikosteroid intralesi, krioterapi, atau terapi laser vaskular."
  },
  KEP02: {
    id: "KEP02",
    name: "Melasma",
    description: "Melasma merupakan kondisi hiperpigmentasi yang ditandai dengan munculnya bercak coklat kehitaman dengan pola simetris pada area wajah (pipi, dahi, leher) akibat kombinasi paparan sinar UV dan hormon.",
    solution: "Gunakan tabir surya (sunscreen) broad-spectrum SPF minimal 30 secara rutin setiap 2-3 jam, hindari paparan sinar matahari langsung (gunakan topi/payung), serta gunakan krim pencerah (seperti azelaic acid atau retinoid) sesuai anjuran dokter."
  },
  KEP03: {
    id: "KEP03",
    name: "Akne Vulgaris",
    description: "Akne Vulgaris (jerawat) adalah penyakit peradangan kronis pada unit pilosebasea yang disertai pembentukan komedo, papul, benjolan padat, hingga benjolan bernanah (pustul/kista).",
    solution: "Menjaga kebersihan wajah dengan mencuci muka 2 kali sehari, gunakan produk perawatan berlabel 'non-comedogenic', kelola stres dengan baik, hindari memencet jerawat, serta kurangi penggunaan riasan (kosmetik) yang tebal."
  },
  KEP04: {
    id: "KEP04",
    name: "Selulit",
    description: "Selulit merupakan perubahan topografi kulit di mana jaringan lemak menembus lapisan jaringan ikat kulit, menghasilkan tekstur bergelombang atau menyerupai kulit jeruk (orange peel skin), umumnya pada paha dan bokong.",
    solution: "Lakukan olahraga kardio dan pengencangan otot secara teratur, jaga berat badan ideal, penuhi kebutuhan hidrasi harian (minimal 2 liter air putih), kurangi makanan berlemak tinggi/garam, serta lakukan pemijatan (dry brushing/massage) pada area kulit bersangkutan."
  },
  KEP05: {
    id: "KEP05",
    name: "Penuaan Kulit",
    description: "Penuaan kulit (skin aging) adalah penurunan elastisitas, dehidrasi, dan kerusakan kolagen alami pada kulit wajah yang menyebabkan munculnya garis senyum mendalam, kerutan halus, serta kulit yang kering dan kendur.",
    solution: "Gunakan pelembap yang mengandung ceramide/hyaluronic acid secara teratur, disiplin mengaplikasikan sunscreen setiap hari, konsumsi makanan bergizi kaya antioksidan (vitamin C dan E), cukup tidur, dan hindari paparan asap rokok."
  },
  KEP06: {
    id: "KEP06",
    name: "Veruka Vulgaris",
    description: "Veruka Vulgaris (kutil umum) merupakan hiperplasia epidermal jinak yang dipicu infeksi virus Human Papillomavirus (HPV). Ditandai dengan benjolan kecil padat, permukaan kasar bersisik, dan batas lesi bervariasi.",
    solution: "Hindari menyentuh, menggaruk, atau mengorek kutil secara langsung agar tidak menular ke area tubuh lain. Jaga kebersihan kulit dan konsultasikan ke dokter untuk tindakan medis seperti terapi asam salisilat topikal, elektrokauterisasi, atau bedah beku (krioterapi)."
  }
};

/**
 * B. DATA GEJALA KLINIS (G) - 29 Gejala Kulit
 */
const SYMPTOMS = [
  { id: "KEG01", name: "Riwayat luka (pipi, pundak, lengan atas, daun telinga, dada)" },
  { id: "KEG02", name: "Plak yang tumbuh pada bekas luka berwarna merah muda/keunguan" },
  { id: "KEG03", name: "Muncul tukak" },
  { id: "KEG04", name: "Terasa gatal" },
  { id: "KEG05", name: "Bercak coklat kehitaman (wajah, leher)" },
  { id: "KEG06", name: "Ukuran bercak bervariasi" },
  { id: "KEG07", name: "Pola bercak menyebar" },
  { id: "KEG08", name: "Beraktivitas terpapar sinar matahari" },
  { id: "KEG09", name: "Kehamilan" },
  { id: "KEG10", name: "Mengkonsumsi obat hormon" },
  { id: "KEG11", name: "Muncul komedo" },
  { id: "KEG12", name: "Benjolan padat" },
  { id: "KEG13", name: "Faktor genetik keluarga" },
  { id: "KEG14", name: "Penggunaan kosmetik" },
  { id: "KEG15", name: "Mengalami stres" },
  { id: "KEG16", name: "Mengalami gangguan siklus menstruasi" },
  { id: "KEG17", name: "Pola hidup yang tidak sehat" },
  { id: "KEG18", name: "Benjolan bernanah" },
  { id: "KEG19", name: "Kulit membulat (perut, paha)" },
  { id: "KEG20", name: "Kulit kurang mengencang" },
  { id: "KEG21", name: "Permukaan kulit seperti kulit jeruk" },
  { id: "KEG22", name: "Mengalami berat badan berlebih" },
  { id: "KEG23", name: "Usia di atas 30 tahun" },
  { id: "KEG24", name: "Kulit wajah mengalami kerutan" },
  { id: "KEG25", name: "Kulit wajah kering" },
  { id: "KEG26", name: "Muncul garis senyum pada wajah" },
  { id: "KEG27", name: "Penonjolan daging pada kulit" },
  { id: "KEG28", name: "Permukaan benjolan kasar bersisik" },
  { id: "KEG29", name: "Ukuran lesi bervariasi" }
];

/**
 * C. SKALA TINGKAT KEYAKINAN PENGGUNA (CF USER)
 */
const CF_SCALE = [
  { label: "Tidak Tahu", value: 0.0 },
  { label: "Mungkin", value: 0.4 },
  { label: "Kemungkinan Besar", value: 0.6 },
  { label: "Hampir Pasti", value: 0.8 },
  { label: "Pasti", value: 1.0 }
];

/**
 * D. BASIS ATURAN INFERENSI (RULES) - 28 Aturan Berdasarkan Jurnal
 */
const RULES = [
  // --- Keloid (KEP01) ---
  { id: "R1", diseaseId: "KEP01", premises: ["KEG01", "KEG02"], cfPakar: 0.8 },
  { id: "R2", diseaseId: "KEP01", premises: ["KEG01", "KEG02", "KEG03"], cfPakar: 0.8 },
  { id: "R3", diseaseId: "KEP01", premises: ["KEG01", "KEG02", "KEG04"], cfPakar: 0.8 },

  // --- Melasma (KEP02) ---
  { id: "R4", diseaseId: "KEP02", premises: ["KEG05", "KEG06"], cfPakar: 0.6 },
  { id: "R5", diseaseId: "KEP02", premises: ["KEG05", "KEG06", "KEG07"], cfPakar: 0.8 },
  { id: "R6", diseaseId: "KEP02", premises: ["KEG05", "KEG06", "KEG08"], cfPakar: 0.8 },
  { id: "R7", diseaseId: "KEP02", premises: ["KEG05", "KEG06", "KEG09"], cfPakar: 0.8 },
  { id: "R8", diseaseId: "KEP02", premises: ["KEG05", "KEG06", "KEG10"], cfPakar: 0.6 },

  // --- Akne Vulgaris (KEP03) ---
  { id: "R9",  diseaseId: "KEP03", premises: ["KEG11", "KEG12", "KEG18"], cfPakar: 0.8 },
  { id: "R10", diseaseId: "KEP03", premises: ["KEG11", "KEG13"], cfPakar: 0.6 },
  { id: "R11", diseaseId: "KEP03", premises: ["KEG11", "KEG14"], cfPakar: 0.6 },
  { id: "R12", diseaseId: "KEP03", premises: ["KEG11", "KEG15"], cfPakar: 0.6 },
  { id: "R13", diseaseId: "KEP03", premises: ["KEG11", "KEG16"], cfPakar: 0.8 },
  { id: "R14", diseaseId: "KEP03", premises: ["KEG11", "KEG17"], cfPakar: 0.6 },
  { id: "R15", diseaseId: "KEP03", premises: ["KEG11", "KEG12"], cfPakar: 0.8 },
  { id: "R16", diseaseId: "KEP03", premises: ["KEG04", "KEG11", "KEG12"], cfPakar: 0.8 },

  // --- Selulit (KEP04) ---
  { id: "R17", diseaseId: "KEP04", premises: ["KEG13", "KEG19", "KEG20"], cfPakar: 0.6 },
  { id: "R18", diseaseId: "KEP04", premises: ["KEG19", "KEG20", "KEG21"], cfPakar: 0.8 },
  { id: "R19", diseaseId: "KEP04", premises: ["KEG19", "KEG20"], cfPakar: 0.6 },
  { id: "R20", diseaseId: "KEP04", premises: ["KEG19", "KEG20", "KEG22"], cfPakar: 0.8 },

  // --- Penuaan Kulit (KEP05) ---
  { id: "R21", diseaseId: "KEP05", premises: ["KEG23", "KEG24", "KEG26"], cfPakar: 0.6 },
  { id: "R22", diseaseId: "KEP05", premises: ["KEG08", "KEG24", "KEG26"], cfPakar: 0.8 },
  { id: "R23", diseaseId: "KEP05", premises: ["KEG17", "KEG24", "KEG26"], cfPakar: 0.6 },
  { id: "R24", diseaseId: "KEP05", premises: ["KEG24", "KEG26"], cfPakar: 0.6 },
  { id: "R25", diseaseId: "KEP05", premises: ["KEG24", "KEG25", "KEG26"], cfPakar: 0.8 },

  // --- Veruka Vulgaris (KEP06) ---
  { id: "R26", diseaseId: "KEP06", premises: ["KEG27", "KEG28"], cfPakar: 0.8 },
  { id: "R27", diseaseId: "KEP06", premises: ["KEG27", "KEG28", "KEG29"], cfPakar: 0.6 },
  { id: "R28", diseaseId: "KEP06", premises: ["KEG04", "KEG27", "KEG28", "KEG29"], cfPakar: 0.6 }
];

/**
 * E. PRESET SKENARIO PENGUJIAN (UNTUK DEMO SIDANG)
 */
const DEMO_SCENARIOS = {
  keloid: {
    title: "Keloid",
    inputs: { "KEG01": 1.0, "KEG02": 1.0, "KEG03": 0.8 }
  },
  melasma: {
    title: "Melasma",
    inputs: { "KEG05": 1.0, "KEG06": 1.0, "KEG07": 0.8, "KEG08": 0.8 }
  },
  akne: {
    title: "Akne Vulgaris",
    inputs: { "KEG04": 0.6, "KEG11": 1.0, "KEG12": 0.8, "KEG18": 0.8 }
  },
  selulit: {
    title: "Selulit",
    inputs: { "KEG19": 1.0, "KEG20": 1.0, "KEG21": 0.8, "KEG22": 0.8 }
  },
  penuaan: {
    title: "Penuaan Kulit",
    inputs: { "KEG23": 0.8, "KEG24": 1.0, "KEG25": 0.8, "KEG26": 1.0 }
  },
  veruka: {
    title: "Veruka Vulgaris",
    inputs: { "KEG27": 1.0, "KEG28": 1.0, "KEG29": 0.8 }
  },
  seri: {
    title: "Kasus Seri (Draw)",
    inputs: { "KEG01": 1.0, "KEG02": 1.0, "KEG27": 1.0, "KEG28": 1.0 }
  }
};

const STORAGE_KEY_HISTORY = "derm_cf_history_records";


/* ============================================================================
   2. STATE MANAGEMENT & DOM REFERENCES
   ============================================================================ */

const userSelections = {}; // Format: { "KEG01": 0.0, ... }

// DOM Elements
const symptomsContainer = document.getElementById("symptomsContainer");
const consultationForm = document.getElementById("consultationForm");
const patientNameInput = document.getElementById("patientNameInput");
const patientAgeInput = document.getElementById("patientAgeInput");
const symptomSearch = document.getElementById("symptomSearch");
const btnClearSearch = document.getElementById("btnClearSearch");
const totalSelectedCount = document.getElementById("totalSelectedCount");
const btnResetAll = document.getElementById("btnResetAll");
const btnFormReset = document.getElementById("btnFormReset");
const formStatusDot = document.getElementById("formStatusDot");
const formStatusText = document.getElementById("formStatusText");
const resultsSection = document.getElementById("resultsSection");
const patientResultMeta = document.getElementById("patientResultMeta");
const tieAlertBanner = document.getElementById("tieAlertBanner");
const topDiagnosesGrid = document.getElementById("topDiagnosesGrid");
const allDiseasesRanking = document.getElementById("allDiseasesRanking");
const selectedSymptomsTableBody = document.getElementById("selectedSymptomsTableBody");
const selectedSymptomsBadge = document.getElementById("selectedSymptomsBadge");
const ruleEvalTableBody = document.getElementById("ruleEvalTableBody");
const combineStepsContainer = document.getElementById("combineStepsContainer");
const btnToggleCalc = document.getElementById("btnToggleCalc");
const calcBody = document.getElementById("calcBody");
const btnPrintReport = document.getElementById("btnPrintReport");
const btnRestartConsult = document.getElementById("btnRestartConsult");
const btnViewInHistory = document.getElementById("btnViewInHistory");
const validationModal = document.getElementById("validationModal");
const btnCloseModal = document.getElementById("btnCloseModal");
const scenarioSelect = document.getElementById("scenarioSelect");
const btnLoadScenario = document.getElementById("btnLoadScenario");
const historyCounterBadge = document.getElementById("historyCounterBadge");
const historyListContainer = document.getElementById("historyListContainer");
const btnClearAllHistory = document.getElementById("btnClearAllHistory");
const historyDetailModal = document.getElementById("historyDetailModal");
const btnCloseHistModal = document.getElementById("btnCloseHistModal");
const btnDismissHistModal = document.getElementById("btnDismissHistModal");
const histModalId = document.getElementById("histModalId");
const histModalTitle = document.getElementById("histModalTitle");
const histModalMeta = document.getElementById("histModalMeta");
const histModalContent = document.getElementById("histModalContent");
const btnPrintHistRecord = document.getElementById("btnPrintHistRecord");
const btnGoToConsult = document.getElementById("btnGoToConsult");
const btnGoToKB = document.getElementById("btnGoToKB");

// KB DOM Elements
const kbDiseasesTableBody = document.getElementById("kbDiseasesTableBody");
const kbSymptomsTableBody = document.getElementById("kbSymptomsTableBody");
const kbRulesTableBody = document.getElementById("kbRulesTableBody");
const kbSymptomSearch = document.getElementById("kbSymptomSearch");
const kbRuleSearch = document.getElementById("kbRuleSearch");


/* ============================================================================
   3. INISIALISASI APLIKASI
   ============================================================================ */

function initApp() {
  // Inisialisasi state gejala
  SYMPTOMS.forEach(s => {
    userSelections[s.id] = 0.0;
  });

  renderSymptomCards(SYMPTOMS);
  updateFormStats();
  renderKnowledgeBase();
  updateHistoryDisplay();
  setupEventListeners();

  // Handle URL Hash navigation on load
  const hash = window.location.hash.replace("#", "");
  if (hash && document.getElementById(hash)) {
    switchSlide(hash);
  } else {
    switchSlide("slide-panduan");
  }
}


/* ============================================================================
   4. SLIDE / TAB VIEW SWITCHING SYSTEM
   ============================================================================ */

/**
 * Berpindah tampilan slide antar: Panduan, Konsultasi, Riwayat, Basis Pengetahuan
 * @param {string} targetSlideId - ID elemen slide target (misal: 'slide-konsultasi')
 */
function switchSlide(targetSlideId) {
  const slides = document.querySelectorAll(".slide-view");
  const navBtns = document.querySelectorAll(".nav-tab-btn");

  slides.forEach(slide => {
    if (slide.id === targetSlideId) {
      slide.classList.add("active");
    } else {
      slide.classList.remove("active");
    }
  });

  navBtns.forEach(btn => {
    if (btn.getAttribute("data-target") === targetSlideId) {
      btn.classList.add("active");
    } else {
      btn.classList.remove("active");
    }
  });

  // Perbarui hash di URL tanpa reload
  if (history.pushState) {
    history.pushState(null, null, `#${targetSlideId}`);
  } else {
    window.location.hash = targetSlideId;
  }

  // Scroll ke atas halaman slide
  window.scrollTo({ top: 0, behavior: "smooth" });
}


/* ============================================================================
   5. RENDERING FORM GEJALA & INTERAKSI
   ============================================================================ */

function renderSymptomCards(symptomList) {
  symptomsContainer.innerHTML = "";

  if (symptomList.length === 0) {
    symptomsContainer.innerHTML = `
      <div style="grid-column: 1 / -1; text-align: center; padding: 40px; background: #fff; border-radius: 12px; border: 1px dashed #cbd5e1;">
        <p style="font-size: 1.1rem; color: #64748b; font-weight: 600;">Gejala tidak ditemukan</p>
        <p style="font-size: 0.85rem; color: #94a3b8;">Coba gunakan kata kunci pencarian yang lain.</p>
      </div>
    `;
    return;
  }

  symptomList.forEach(symptom => {
    const currentValue = userSelections[symptom.id] || 0.0;
    const isActive = currentValue > 0;

    const card = document.createElement("div");
    card.className = `symptom-card ${isActive ? "is-active" : ""}`;
    card.id = `card-${symptom.id}`;

    let optionsHtml = "";
    CF_SCALE.forEach(opt => {
      const selected = Math.abs(currentValue - opt.value) < 0.001 ? "selected" : "";
      optionsHtml += `<option value="${opt.value}" ${selected}>${opt.label} (${opt.value.toFixed(1)})</option>`;
    });

    card.innerHTML = `
      <div class="symptom-header">
        <span class="symptom-code-badge">${symptom.id}</span>
        <label for="select-${symptom.id}" class="symptom-label">
          ${symptom.name}
        </label>
      </div>
      <div class="symptom-selector-wrap">
        <span class="select-prompt">Tingkat Keyakinan:</span>
        <select 
          id="select-${symptom.id}" 
          class="symptom-select" 
          data-symptom-id="${symptom.id}"
          aria-label="Tingkat keyakinan untuk ${symptom.name}"
        >
          ${optionsHtml}
        </select>
      </div>
    `;

    symptomsContainer.appendChild(card);
  });
}

function updateFormStats() {
  let activeCount = 0;
  for (const id in userSelections) {
    if (userSelections[id] > 0) activeCount++;
  }

  totalSelectedCount.textContent = activeCount;

  if (activeCount > 0) {
    formStatusDot.classList.add("active");
    formStatusText.textContent = `${activeCount} gejala aktif dipilih. Siap untuk diproses.`;
    formStatusText.style.color = "#0f766e";
  } else {
    formStatusDot.classList.remove("active");
    formStatusText.textContent = "Pilih minimal 1 gejala untuk memproses diagnosis.";
    formStatusText.style.color = "#64748b";
  }
}


/* ============================================================================
   6. LOGIKA INFERENSI CERTAINTY FACTOR (CF)
   ============================================================================ */

/**
 * Kalkulasi Certainty Factor Multi-Premise AND & Kombinasi Berantai
 * @param {Object} inputs - Objek { "KEG01": 0.8, ... }
 * @returns {Object} Hasil kalkulasi lengkap & rekaman trace
 */
function calculateCertaintyFactor(inputs) {
  const calculationTrace = {
    activeRules: [],
    diseaseCombines: {}
  };

  const diseaseRuleMap = {
    KEP01: [],
    KEP02: [],
    KEP03: [],
    KEP04: [],
    KEP05: [],
    KEP06: []
  };

  // Tahap 1: Evaluasi 28 Aturan
  RULES.forEach(rule => {
    const premiseUserValues = rule.premises.map(premiseId => {
      return {
        premiseId: premiseId,
        userValue: Number(inputs[premiseId] || 0.0)
      };
    });

    const minUserCf = Math.min(...premiseUserValues.map(p => p.userValue));
    let cfRule = 0;
    const isActive = minUserCf > 0;

    if (isActive) {
      cfRule = minUserCf * rule.cfPakar;
      diseaseRuleMap[rule.diseaseId].push({
        ruleId: rule.id,
        cfRule: cfRule,
        minUserCf: minUserCf,
        cfPakar: rule.cfPakar,
        premises: premiseUserValues
      });
    }

    calculationTrace.activeRules.push({
      ruleId: rule.id,
      diseaseId: rule.diseaseId,
      premises: premiseUserValues,
      minUserCf: minUserCf,
      cfPakar: rule.cfPakar,
      cfRule: cfRule,
      isActive: isActive
    });
  });

  // Tahap 2: Kombinasi Berantai per Penyakit
  const finalResults = [];

  Object.keys(DISEASES).forEach(diseaseId => {
    const rulesForDisease = diseaseRuleMap[diseaseId];
    const diseaseInfo = DISEASES[diseaseId];
    const combineHistory = [];
    let finalCf = 0.0;

    if (rulesForDisease.length === 0) {
      finalCf = 0.0;
    } else if (rulesForDisease.length === 1) {
      finalCf = rulesForDisease[0].cfRule;
      combineHistory.push({
        step: 1,
        formula: `CF_total = ${rulesForDisease[0].ruleId} = ${finalCf.toFixed(4)}`,
        result: finalCf
      });
    } else {
      let currentCf = rulesForDisease[0].cfRule;
      combineHistory.push({
        step: 1,
        formula: `CF_awal (${rulesForDisease[0].ruleId}) = ${currentCf.toFixed(4)}`,
        result: currentCf
      });

      for (let i = 1; i < rulesForDisease.length; i++) {
        const nextRule = rulesForDisease[i];
        const cfNext = nextRule.cfRule;
        const prevCf = currentCf;
        const combined = prevCf + cfNext * (1 - prevCf);

        combineHistory.push({
          step: i + 1,
          formula: `CF_gab_${i} = ${prevCf.toFixed(4)} + ${cfNext.toFixed(4)} &times; (1 - ${prevCf.toFixed(4)}) = ${combined.toFixed(4)}`,
          result: combined
        });

        currentCf = combined;
      }

      finalCf = currentCf;
    }

    const percentage = Number((finalCf * 100).toFixed(2));

    calculationTrace.diseaseCombines[diseaseId] = {
      diseaseName: diseaseInfo.name,
      rulesCount: rulesForDisease.length,
      history: combineHistory,
      finalCf: finalCf,
      percentage: percentage
    };

    finalResults.push({
      diseaseId: diseaseId,
      name: diseaseInfo.name,
      description: diseaseInfo.description,
      solution: diseaseInfo.solution,
      cfValue: finalCf,
      percentage: percentage,
      rulesFiredCount: rulesForDisease.length
    });
  });

  // Tahap 3: Pengurutan Hasil
  finalResults.sort((a, b) => b.percentage - a.percentage);

  const highestScore = finalResults[0].percentage;
  const topWinners = finalResults.filter(
    item => highestScore > 0 && Math.abs(item.percentage - highestScore) < 0.001
  );

  return {
    rankedResults: finalResults,
    topWinners: topWinners,
    isTie: topWinners.length > 1,
    hasMatch: highestScore > 0,
    trace: calculationTrace
  };
}


/* ============================================================================
   7. RENDERING HASIL DIAGNOSA & PENYIMPANAN RIWAYAT
   ============================================================================ */

function renderDiagnosisResults(cfData, inputs, shouldSaveHistory = true) {
  resultsSection.style.display = "block";
  resultsSection.scrollIntoView({ behavior: "smooth", block: "start" });

  const patientName = patientNameInput.value.trim() || "Pasien Umum";
  const patientAge = patientAgeInput.value ? `${patientAgeInput.value} Tahun` : "-";
  const now = new Date();
  const dateFormatted = now.toLocaleDateString("id-ID", {
    day: "numeric", month: "short", year: "numeric",
    hour: "2-digit", minute: "2-digit"
  });

  patientResultMeta.innerHTML = `Data Pasien: <strong>${patientName}</strong> (${patientAge}) &bull; Waktu Analisis: ${dateFormatted} WIB`;

  // Handling Hasil Seri / Draw
  if (cfData.isTie) {
    tieAlertBanner.style.display = "flex";
    topDiagnosesGrid.classList.add("is-tie");
  } else {
    tieAlertBanner.style.display = "none";
    topDiagnosesGrid.classList.remove("is-tie");
  }

  // Render Pemenang
  topDiagnosesGrid.innerHTML = "";
  if (!cfData.hasMatch) {
    topDiagnosesGrid.innerHTML = `
      <div class="winner-card" style="border-color: #cbd5e1; text-align: center; padding: 40px 24px;">
        <div style="font-size: 2.5rem; margin-bottom: 12px;">ℹ️</div>
        <h3 style="font-size: 1.4rem; color: #334155; margin-bottom: 8px;">Tidak Ada Penyakit yang Cocok</h3>
        <p style="color: #64748b; max-width: 600px; margin: 0 auto 16px;">
          Kombinasi gejala yang Anda pilih belum memenuhi salah satu dari 28 aturan pada basis pengetahuan.
          Silakan tinjau kembali gejala klinis lain untuk melengkapi premis aturan.
        </p>
      </div>
    `;
  } else {
    cfData.topWinners.forEach(winner => {
      const card = document.createElement("div");
      card.className = "winner-card";
      card.innerHTML = `
        <div class="winner-header">
          <div>
            <span class="winner-code-pill">${winner.diseaseId}</span>
            <h3 class="winner-name">${winner.name}</h3>
          </div>
          <div class="score-badge">
            <span class="score-label">Tingkat Keyakinan</span>
            <div class="score-value">${winner.percentage}%</div>
            <span class="score-cf-decimal">CF: ${winner.cfValue.toFixed(4)}</span>
          </div>
        </div>
        <p class="winner-desc">${winner.description}</p>
        <div class="solution-box">
          <h4 class="solution-box-title">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"></path>
            </svg>
            Rekomendasi Solusi &amp; Penanganan Medis:
          </h4>
          <p class="solution-box-content">${winner.solution}</p>
        </div>
      `;
      topDiagnosesGrid.appendChild(card);
    });
  }

  // Render Peringkat 6 Penyakit
  allDiseasesRanking.innerHTML = "";
  const maxVal = Math.max(...cfData.rankedResults.map(r => r.percentage), 1);

  cfData.rankedResults.forEach((item, idx) => {
    const isTop = cfData.hasMatch && item.percentage === cfData.topWinners[0].percentage;
    const rankingEl = document.createElement("div");
    rankingEl.className = `ranking-item ${isTop ? "top-rank" : ""}`;
    rankingEl.innerHTML = `
      <div class="ranking-info">
        <span class="ranking-name">
          <strong>#${idx + 1}</strong>
          <span class="ranking-code">${item.diseaseId}</span>
          ${item.name}
        </span>
        <span class="ranking-percent">${item.percentage}% (CF: ${item.cfValue.toFixed(4)})</span>
      </div>
      <div class="ranking-bar-bg">
        <div class="ranking-bar-fill" style="width: ${(item.percentage / maxVal) * 100}%;"></div>
      </div>
    `;
    allDiseasesRanking.appendChild(rankingEl);
  });

  // Render Tabel Gejala Terpilih
  selectedSymptomsTableBody.innerHTML = "";
  let selectedSymptomsCount = 0;
  const selectedSymptomsList = [];

  SYMPTOMS.forEach(symptom => {
    const val = Number(inputs[symptom.id] || 0.0);
    if (val > 0) {
      selectedSymptomsCount++;
      const scaleObj = CF_SCALE.find(s => Math.abs(s.value - val) < 0.001) || { label: "Kustom" };
      selectedSymptomsList.push({
        id: symptom.id,
        name: symptom.name,
        userValue: val,
        scaleLabel: scaleObj.label
      });

      const tr = document.createElement("tr");
      tr.innerHTML = `
        <td><span class="symptom-code-badge" style="background:#fce7f3; color:#be185d;">${symptom.id}</span></td>
        <td><strong>${symptom.name}</strong></td>
        <td><span class="legend-chip chip-${Math.round(val * 4)}">${scaleObj.label}</span></td>
        <td style="text-align: center; font-family: monospace; font-weight: 700;">${val.toFixed(1)}</td>
      `;
      selectedSymptomsTableBody.appendChild(tr);
    }
  });

  selectedSymptomsBadge.textContent = `${selectedSymptomsCount} Gejala Terpilih`;

  // Render Transparansi Tahap 1
  ruleEvalTableBody.innerHTML = "";
  const activeRulesList = cfData.trace.activeRules.filter(r => r.isActive);

  if (activeRulesList.length === 0) {
    ruleEvalTableBody.innerHTML = `
      <tr>
        <td colspan="6" style="text-align:center; padding: 20px; color: #94a3b8;">
          Tidak ada rule yang aktif karena premis gejala belum terpenuhi.
        </td>
      </tr>
    `;
  } else {
    activeRulesList.forEach(r => {
      const premiseDetails = r.premises.map(p => `${p.premiseId} (${p.userValue.toFixed(1)})`).join(" &amp; ");
      const tr = document.createElement("tr");
      tr.innerHTML = `
        <td><strong>${r.ruleId}</strong></td>
        <td><span class="ranking-code">${r.diseaseId}</span> ${DISEASES[r.diseaseId].name}</td>
        <td><small>${premiseDetails}</small></td>
        <td style="text-align: center; font-family: monospace;">${r.minUserCf.toFixed(2)}</td>
        <td style="text-align: center; font-family: monospace;">${r.cfPakar.toFixed(2)}</td>
        <td style="text-align: center; font-family: monospace; font-weight: 700; color: #0f766e;">
          ${r.cfRule.toFixed(4)}
        </td>
      `;
      ruleEvalTableBody.appendChild(tr);
    });
  }

  // Render Transparansi Tahap 2
  combineStepsContainer.innerHTML = "";
  Object.keys(cfData.trace.diseaseCombines).forEach(diseaseId => {
    const item = cfData.trace.diseaseCombines[diseaseId];
    if (item.rulesCount > 0) {
      const card = document.createElement("div");
      card.className = "disease-combine-card";

      let stepsHtml = "";
      item.history.forEach(h => {
        stepsHtml += `<li class="combine-calc-step">${h.formula}</li>`;
      });

      card.innerHTML = `
        <div class="disease-combine-header">
          <span>[${diseaseId}] ${item.diseaseName} &bull; ${item.rulesCount} Rule Aktif</span>
          <span style="font-size: 0.9rem; font-weight: 800; color: #0f766e;">
            CF Akhir: ${item.finalCf.toFixed(4)} (${item.percentage}%)
          </span>
        </div>
        <ul class="combine-calc-list">
          ${stepsHtml}
        </ul>
      `;

      combineStepsContainer.appendChild(card);
    }
  });

  // Simpan ke Riwayat (localStorage)
  if (shouldSaveHistory && cfData.hasMatch) {
    saveConsultationRecord({
      id: "REC-" + Date.now(),
      timestamp: Date.now(),
      dateStr: dateFormatted,
      patientName: patientName,
      patientAge: patientAge,
      topWinners: cfData.topWinners,
      isTie: cfData.isTie,
      rankedResults: cfData.rankedResults,
      selectedSymptoms: selectedSymptomsList,
      activeRulesCount: activeRulesList.length
    });
  }
}


/* ============================================================================
   8. MANAJEMEN RIWAYAT KONSULTASI (LOCALSTORAGE)
   ============================================================================ */

function getStoredHistory() {
  try {
    const data = localStorage.getItem(STORAGE_KEY_HISTORY);
    return data ? JSON.parse(data) : [];
  } catch (err) {
    console.error("Gagal membaca riwayat:", err);
    return [];
  }
}

function saveConsultationRecord(record) {
  try {
    const currentList = getStoredHistory();
    currentList.unshift(record); // Tambah paling depan
    localStorage.setItem(STORAGE_KEY_HISTORY, JSON.stringify(currentList));
    updateHistoryDisplay();
  } catch (err) {
    console.error("Gagal menyimpan riwayat:", err);
  }
}

function deleteHistoryRecord(id) {
  if (confirm("Hapus catatan rekam konsultasi ini?")) {
    const list = getStoredHistory().filter(item => item.id !== id);
    localStorage.setItem(STORAGE_KEY_HISTORY, JSON.stringify(list));
    updateHistoryDisplay();
  }
}

function clearAllHistory() {
  if (confirm("Apakah Anda yakin ingin menghapus SELURUH riwayat konsultasi? Tindakan ini tidak dapat dibatalkan.")) {
    localStorage.removeItem(STORAGE_KEY_HISTORY);
    updateHistoryDisplay();
  }
}

function updateHistoryDisplay() {
  const historyList = getStoredHistory();
  historyCounterBadge.textContent = historyList.length;

  historyListContainer.innerHTML = "";

  if (historyList.length === 0) {
    historyListContainer.innerHTML = `
      <div class="empty-history-box">
        <div class="empty-history-icon">🕒</div>
        <h3 class="empty-history-title">Belum Ada Riwayat Konsultasi</h3>
        <p class="empty-history-desc">
          Semua hasil diagnosa pasien yang telah diproses akan otomatis tersimpan di sini.
        </p>
        <button type="button" class="btn-primary-sm" onclick="switchSlide('slide-konsultasi')">
          Mulai Konsultasi Baru
        </button>
      </div>
    `;
    return;
  }

  historyList.forEach(item => {
    const card = document.createElement("div");
    card.className = "history-card-item";

    const topNames = item.topWinners.map(w => `${w.name} (${w.percentage}%)`).join(", ");
    const isTieBadge = item.isTie ? `<span class="legend-chip chip-2" style="font-size:0.7rem;">SERI</span>` : "";

    card.innerHTML = `
      <div class="history-main-info">
        <div class="history-meta-row">
          <span>📅 ${item.dateStr}</span>
          <span>&bull;</span>
          <span>👤 ${item.patientAge}</span>
          <span>&bull;</span>
          <span>🔍 ${item.selectedSymptoms.length} Gejala Dipilih</span>
        </div>
        <h3 class="history-patient-name">${item.patientName}</h3>
        <div class="history-result-badge">
          <span>Diagnosa: <strong>${topNames}</strong></span>
          ${isTieBadge}
        </div>
      </div>
      <div class="history-item-actions">
        <button type="button" class="btn-history-view" data-record-id="${item.id}">
          Lihat Rincian
        </button>
        <button type="button" class="btn-history-delete" data-record-id="${item.id}" title="Hapus catatan">
          Hapus
        </button>
      </div>
    `;

    historyListContainer.appendChild(card);
  });
}

function openHistoryDetailModal(recordId) {
  const historyList = getStoredHistory();
  const record = historyList.find(r => r.id === recordId);
  if (!record) return;

  histModalId.textContent = record.id;
  histModalTitle.textContent = `Rekam Konsultasi: ${record.patientName}`;
  histModalMeta.textContent = `Tanggal: ${record.dateStr} WIB | Usia: ${record.patientAge}`;

  let winnersHtml = "";
  record.topWinners.forEach(w => {
    winnersHtml += `
      <div class="winner-card" style="margin-bottom: 14px; padding: 20px;">
        <div class="winner-header">
          <div>
            <span class="winner-code-pill">${w.diseaseId}</span>
            <h3 class="winner-name" style="font-size: 1.4rem;">${w.name}</h3>
          </div>
          <div class="score-badge" style="padding: 6px 14px;">
            <div class="score-value" style="font-size: 1.6rem;">${w.percentage}%</div>
            <span class="score-cf-decimal">CF: ${w.cfValue.toFixed(4)}</span>
          </div>
        </div>
        <p class="winner-desc" style="font-size: 0.9rem;">${w.description}</p>
        <div class="solution-box" style="padding: 12px;">
          <h4 class="solution-box-title" style="font-size: 0.85rem;">Rekomendasi Solusi:</h4>
          <p class="solution-box-content" style="font-size: 0.85rem;">${w.solution}</p>
        </div>
      </div>
    `;
  });

  let symptomsHtml = "";
  record.selectedSymptoms.forEach(s => {
    symptomsHtml += `
      <tr>
        <td><span class="symptom-code-badge">${s.id}</span></td>
        <td>${s.name}</td>
        <td><span class="legend-chip chip-1">${s.scaleLabel} (${s.userValue})</span></td>
      </tr>
    `;
  });

  histModalContent.innerHTML = `
    <h4 style="margin-bottom: 8px; color: var(--primary);">Hasil Diagnosa Utama:</h4>
    ${winnersHtml}

    <h4 style="margin-top: 18px; margin-bottom: 8px; color: var(--text-main);">
      Gejala yang Dipilih (${record.selectedSymptoms.length}):
    </h4>
    <div class="table-responsive">
      <table class="data-table">
        <thead>
          <tr>
            <th style="width: 100px;">Kode</th>
            <th>Gejala</th>
            <th style="width: 180px;">Tingkat Keyakinan</th>
          </tr>
        </thead>
        <tbody>
          ${symptomsHtml}
        </tbody>
      </table>
    </div>
  `;

  historyDetailModal.style.display = "flex";
}


/* ============================================================================
   9. BASIS PENGETAHUAN (KNOWLEDGE BASE) TAB
   ============================================================================ */

function renderKnowledgeBase() {
  // Render Penyakit
  kbDiseasesTableBody.innerHTML = "";
  Object.keys(DISEASES).forEach(id => {
    const d = DISEASES[id];
    const tr = document.createElement("tr");
    tr.innerHTML = `
      <td><span class="winner-code-pill">${d.id}</span></td>
      <td><strong>${d.name}</strong></td>
      <td style="font-size: 0.875rem;">${d.description}</td>
      <td style="font-size: 0.875rem; color: #166534;">${d.solution}</td>
    `;
    kbDiseasesTableBody.appendChild(tr);
  });

  // Render Gejala
  renderKBSymptoms(SYMPTOMS);

  // Render Rules
  renderKBRules(RULES);
}

function renderKBSymptoms(symptomsList) {
  kbSymptomsTableBody.innerHTML = "";
  symptomsList.forEach(s => {
    const tr = document.createElement("tr");
    tr.innerHTML = `
      <td><span class="symptom-code-badge">${s.id}</span></td>
      <td>${s.name}</td>
    `;
    kbSymptomsTableBody.appendChild(tr);
  });
}

function renderKBRules(rulesList) {
  kbRulesTableBody.innerHTML = "";
  rulesList.forEach(r => {
    const premisesStr = r.premises.map(p => {
      const sym = SYMPTOMS.find(s => s.id === p);
      return `<strong>${p}</strong> (${sym ? sym.name : ''})`;
    }).join(" <br><strong>AND</strong> ");

    const tr = document.createElement("tr");
    tr.innerHTML = `
      <td><strong>${r.id}</strong></td>
      <td><span class="ranking-code">${r.diseaseId}</span> ${DISEASES[r.diseaseId].name}</td>
      <td style="font-size: 0.85rem; line-height: 1.5;">${premisesStr}</td>
      <td style="text-align: center; font-family: monospace; font-weight: 700; color: #0f766e;">${r.cfPakar.toFixed(2)}</td>
    `;
    kbRulesTableBody.appendChild(tr);
  });
}


/* ============================================================================
   10. EVENT LISTENERS
   ============================================================================ */

function setupEventListeners() {
  // Navigasi Slide Tabs
  document.querySelectorAll(".nav-tab-btn").forEach(btn => {
    btn.addEventListener("click", () => {
      const target = btn.getAttribute("data-target");
      switchSlide(target);
    });
  });

  // Tombol CTA di Hero Panduan
  if (btnGoToConsult) {
    btnGoToConsult.addEventListener("click", () => switchSlide("slide-konsultasi"));
  }
  if (btnGoToKB) {
    btnGoToKB.addEventListener("click", () => switchSlide("slide-basis-pengetahuan"));
  }
  if (btnViewInHistory) {
    btnViewInHistory.addEventListener("click", () => switchSlide("slide-riwayat"));
  }

  // KB Sub-Tabs
  document.querySelectorAll(".kb-tab-btn").forEach(btn => {
    btn.addEventListener("click", () => {
      document.querySelectorAll(".kb-tab-btn").forEach(b => b.classList.remove("active"));
      document.querySelectorAll(".kb-panel").forEach(p => p.classList.remove("active"));

      btn.classList.add("active");
      const targetPanelId = btn.getAttribute("data-kb-target");
      const targetPanel = document.getElementById(targetPanelId);
      if (targetPanel) targetPanel.classList.add("active");
    });
  });

  // KB Symptoms Search
  if (kbSymptomSearch) {
    kbSymptomSearch.addEventListener("input", (e) => {
      const q = e.target.value.toLowerCase().trim();
      const filtered = SYMPTOMS.filter(s => s.id.toLowerCase().includes(q) || s.name.toLowerCase().includes(q));
      renderKBSymptoms(filtered);
    });
  }

  // KB Rules Search
  if (kbRuleSearch) {
    kbRuleSearch.addEventListener("input", (e) => {
      const q = e.target.value.toLowerCase().trim();
      const filtered = RULES.filter(r => {
        const disName = DISEASES[r.diseaseId].name.toLowerCase();
        return r.id.toLowerCase().includes(q) || r.diseaseId.toLowerCase().includes(q) || disName.includes(q);
      });
      renderKBRules(filtered);
    });
  }

  // Delegasi Event Nilai Gejala
  symptomsContainer.addEventListener("change", (e) => {
    if (e.target.classList.contains("symptom-select")) {
      const symptomId = e.target.getAttribute("data-symptom-id");
      const val = parseFloat(e.target.value);
      userSelections[symptomId] = val;

      const card = document.getElementById(`card-${symptomId}`);
      if (card) {
        if (val > 0) card.classList.add("is-active");
        else card.classList.remove("is-active");
      }
      updateFormStats();
    }
  });

  // Filter Gejala Real-Time Form
  symptomSearch.addEventListener("input", (e) => {
    const q = e.target.value.trim().toLowerCase();
    btnClearSearch.style.display = q.length > 0 ? "block" : "none";
    const filtered = SYMPTOMS.filter(s => s.id.toLowerCase().includes(q) || s.name.toLowerCase().includes(q));
    renderSymptomCards(filtered);
  });

  btnClearSearch.addEventListener("click", () => {
    symptomSearch.value = "";
    btnClearSearch.style.display = "none";
    renderSymptomCards(SYMPTOMS);
  });

  // Reset Pilihan
  btnResetAll.addEventListener("click", () => {
    if (confirm("Reset seluruh pilihan gejala kembali ke 'Tidak Tahu'?")) {
      resetUserSelections();
    }
  });

  btnFormReset.addEventListener("click", () => {
    if (confirm("Reset seluruh data formulir konsultasi?")) {
      resetUserSelections();
    }
  });

  // Submit Form Konsultasi
  consultationForm.addEventListener("submit", (e) => {
    e.preventDefault();

    let hasSelected = false;
    for (const id in userSelections) {
      if (userSelections[id] > 0) {
        hasSelected = true;
        break;
      }
    }

    if (!hasSelected) {
      validationModal.style.display = "flex";
      return;
    }

    const cfCalculation = calculateCertaintyFactor(userSelections);
    renderDiagnosisResults(cfCalculation, userSelections, true);
  });

  // Load Demo Skenario
  btnLoadScenario.addEventListener("click", () => {
    const key = scenarioSelect.value;
    if (!key || !DEMO_SCENARIOS[key]) {
      alert("Silakan pilih skenario pengujian terlebih dahulu dari menu dropdown.");
      return;
    }
    loadDemoScenario(key);
  });

  // Close Validation Modal
  btnCloseModal.addEventListener("click", () => {
    validationModal.style.display = "none";
  });
  validationModal.addEventListener("click", (e) => {
    if (e.target === validationModal) validationModal.style.display = "none";
  });

  // History List Actions (Delegation)
  historyListContainer.addEventListener("click", (e) => {
    const viewBtn = e.target.closest(".btn-history-view");
    if (viewBtn) {
      const recordId = viewBtn.getAttribute("data-record-id");
      openHistoryDetailModal(recordId);
      return;
    }

    const delBtn = e.target.closest(".btn-history-delete");
    if (delBtn) {
      const recordId = delBtn.getAttribute("data-record-id");
      deleteHistoryRecord(recordId);
    }
  });

  // Clear All History
  btnClearAllHistory.addEventListener("click", clearAllHistory);

  // Close History Detail Modal
  btnCloseHistModal.addEventListener("click", () => {
    historyDetailModal.style.display = "none";
  });
  btnDismissHistModal.addEventListener("click", () => {
    historyDetailModal.style.display = "none";
  });
  historyDetailModal.addEventListener("click", (e) => {
    if (e.target === historyDetailModal) historyDetailModal.style.display = "none";
  });

  // Print History Detail
  btnPrintHistRecord.addEventListener("click", () => {
    window.print();
  });

  // Toggle Transparansi Kalkulasi
  btnToggleCalc.addEventListener("click", () => {
    const isExpanded = btnToggleCalc.getAttribute("aria-expanded") === "true";
    if (isExpanded) {
      calcBody.style.display = "none";
      btnToggleCalc.setAttribute("aria-expanded", "false");
      btnToggleCalc.textContent = "Tampilkan Rincian";
    } else {
      calcBody.style.display = "flex";
      btnToggleCalc.setAttribute("aria-expanded", "true");
      btnToggleCalc.textContent = "Sembunyikan Rincian";
    }
  });

  // Cetak Laporan PDF
  btnPrintReport.addEventListener("click", () => {
    window.print();
  });

  // Konsultasi Ulang
  btnRestartConsult.addEventListener("click", () => {
    resultsSection.style.display = "none";
    window.scrollTo({ top: 0, behavior: "smooth" });
  });
}

function resetUserSelections() {
  SYMPTOMS.forEach(s => {
    userSelections[s.id] = 0.0;
  });
  renderSymptomCards(SYMPTOMS);
  updateFormStats();
  resultsSection.style.display = "none";
}

function loadDemoScenario(scenarioKey) {
  const scenario = DEMO_SCENARIOS[scenarioKey];
  if (!scenario) return;

  SYMPTOMS.forEach(s => {
    userSelections[s.id] = 0.0;
  });

  for (const symptomId in scenario.inputs) {
    userSelections[symptomId] = scenario.inputs[symptomId];
  }

  symptomSearch.value = "";
  btnClearSearch.style.display = "none";

  renderSymptomCards(SYMPTOMS);
  updateFormStats();

  const cfCalculation = calculateCertaintyFactor(userSelections);
  renderDiagnosisResults(cfCalculation, userSelections, true);
}


/* ============================================================================
   11. RUN APPLICATION ON LOAD
   ============================================================================ */

document.addEventListener("DOMContentLoaded", () => {
  initApp();
  console.log("✅ DermAesthetic Expert System (Certainty Factor) Multi-Slide siap digunakan!");
});
